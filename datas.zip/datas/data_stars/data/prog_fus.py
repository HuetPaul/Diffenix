import os
import numpy as np

# loading the keys 
tab=np.load("grid_uvx_000000-fluxes.npz")
keys=list(tab.key())
keys.append("id_star")

# Find the simulations with smallers rotation periods
prots = []
ids = []
for d in l:
    if 'grid' in d and ".npz" in d:
        tab = np.load(d)
        prots.append(tab["Prot"][0])
        ids.append(int(d[9:-11]))
idx_rot_min = np.argwhere(prots==np.min(prots))[:,0]

res_rot_min={k:[] for k in keys}

for d in l:
    if 'grid' in d and ".npz" in d and int(d[9:-11]) in np.array(ids)[idx_rot_min]:
        tab = np.load(d)
        for k in tab.keys():    
            res_rot_min[k].extend(list(np.array(tab[k])))         
            res_rot_min["id_star"].extend(list(np.full(len(tab["M"]),d[9:-11])))

np.savez_compressed("data_rot_min", **res_rot_min)

# Fusion of all simulations 
res_fus={k:[] for k in keys}

for d in l:
    if 'grid' in d and ".npz" in d:
        tab = np.load(d)
        for k in tab.keys():    
            res_rot_min[k].extend(list(np.array(tab[k])))         
            res_rot_min["id_star"].extend(list(np.full(len(tab["M"]),d[9:-11])))

np.savez_compressed("data_rot_min", **res_rot_min)



